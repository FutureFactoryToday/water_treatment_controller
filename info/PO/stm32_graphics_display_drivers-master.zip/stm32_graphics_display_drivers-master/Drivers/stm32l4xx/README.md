# stm32l4 i/o drivers

- lcd_io_spi.h / c SPI driver (software SPI, hardware SPI, hardware SPI with DMA)
- lcd_io_gpio8.h / c paralell 8 bits GPIO driver 

note: I couldn't test it because I don't have a l4xx board. Please test this and send feedback!