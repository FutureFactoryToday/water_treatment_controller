# ili9341

ili9341.h / c

ILI9341 LCD driver v1.21
- 2019.07. Add v1.1 extension (#ifdef LCD_DRVTYPE_V1_1)
- 2019.11. Add RGB mode with memory frame buffer (in sram or sdram)
- 2020.02  Add analog touchscreen (only 8bit paralell mode)

