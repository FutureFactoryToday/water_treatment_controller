# hx8347g

hx8347g.h / c
  Options for built in analog resistiv touchscreen version 

The my piece doesn't work well for FSMC driver probably too low touchscreen resistor in FSMC pins
(pixel and image reading is wrong)